
import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class NewTest {
	WebDriver driver;
	WebDriverWait mywait;
	String name;
	String baseUrl = "http://demo.automationtesting.in/Alerts.html"; // Assigning the url to String baseUrl

	// 1) Opening the Chrome Browser and Maximizing the window.

	@Test(priority = 1) // Assigning the priority as 1
	public void createDriver() { // Creating the createDriver Method

		// 1) Opening the website.

		driver = new ChromeDriver();

		readFromExcel();

		driver.get(baseUrl);

		mywait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Using ExplicitWait

		driver.manage().window().maximize();

	}

	// 2) Verifying the Title

	@Test(priority = 2)
	public void checkTitleName1() {
		String exp_title = "Automation Demo Site";

		String act_title = driver.findElement(By.xpath("//*[@align='center']//child::h1")).getText();

		assertEquals(act_title, exp_title, "Title check failed "); // Checking exp_title is equal to act_title by using
																	// assertEquals.
	}

//	3) Checking if the Alert popupAppears

	@Test(priority = 3)
	public void checkPopupAppears() {

		WebElement element = driver.findElement(By.className("dropdown-toggle"));
		Actions act = new Actions(driver);

		act.moveToElement(element).perform(); // Moving the cursor from switch to alerts, and performing task.

		driver.findElement(By.linkText("Alerts")).click();

		driver.findElement(By.className("analystic")).click();
		driver.findElement(By.xpath("//*[@id=\"OKTab\"]/button")).click();

		Alert alertWindow = null;

		alertWindow = mywait.until(ExpectedConditions.alertIsPresent());
		alertWindow.accept(); // Clicking on ok.

	}

	@Test(priority = 4)
	public void checkConfirmBox() {

		driver.findElement(By.xpath("//*[@href=\"#CancelTab\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"CancelTab\"]/button")).click();

		Alert alertoc = mywait.until(ExpectedConditions.alertIsPresent());
		{

			alertoc.dismiss(); // Clicking on Cancel.

			String confirmBox = driver.findElement(By.id("demo")).getText();
			System.out.println(confirmBox);
		}
	}

	@Test(priority = 5)
	public void checkPromptBox() {

		driver.findElement(By.linkText("Alert with Textbox")).click();
		driver.findElement(By.xpath("//*[@id=\"Textbox\"]/button")).click();

		Alert alertTbox = mywait.until(ExpectedConditions.alertIsPresent());

		alertTbox.sendKeys(name);
		alertTbox.accept();

		String actMsg = driver.findElement(By.id("demo1")).getText();
		System.out.println(actMsg);
		String expMsg = "Hello " + name + " How are you today";

		assertEquals(actMsg, expMsg, "Incorrect message displayed");

		System.out.println("Correct message displayed");

//		try {
//			assertEquals(y, promptBox);
//			System.out.println("Successfully Validated");
//		} catch (AssertionError e) {
//			System.out.println("Incorrcet message displayed");
//		}

	}

	// @AfterTest
	@Test(priority = 6)
	public void afterTest() {
		System.out.println("Closing the browser");
		driver.quit();
	}

	public void readFromExcel() {
		try {

			File file = new File("C:\\Users/2320026/eclipse-workspace/MiniProject/data.xlsx");

			FileInputStream fis = new FileInputStream(file);

			XSSFWorkbook workbook = new XSSFWorkbook(fis);

			XSSFSheet sheet = workbook.getSheetAt(0);

			int totalRows = sheet.getLastRowNum();

			int totalCells = sheet.getRow(1).getLastCellNum();

			for (int r = 1; r <= totalRows; r++) {

				XSSFRow currentRow = sheet.getRow(r);

				for (int c = 0; c < totalCells; c++) {

					name = currentRow.getCell(c).toString();

					System.out.println(name);
				}
			}
			workbook.close();
			fis.close();

		}

		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}