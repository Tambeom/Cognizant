
import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class NewTest1 {
	WebDriver driver;
	WebDriverWait mywait;
	String name;
	String baseUrl = "http://demo.automationtesting.in/Alerts.html";

	// 1) Opening the Chrome Browser and Maximizing the window.

	@Test(priority = 1)
	public void createDriver() {

		// 1) Opening the website.

		driver = new EdgeDriver();

		readFromExcel();

		driver.get(baseUrl);

		mywait = new WebDriverWait(driver, Duration.ofSeconds(10));

		driver.manage().window().maximize();

	}

	// 2)

	@Test(priority = 2)
	public void checkTitleName1() {
		String exp_title = "Automation Demo Site";

		String act_title = driver.findElement(By.xpath("//*[@align='center']//child::h1")).getText();
		assertEquals(act_title, exp_title, "Title check failed ");
	}

	@Test(priority = 3)
	public void checkPopupAppears() {

		WebElement element = driver.findElement(By.className("dropdown-toggle"));
		Actions act = new Actions(driver);

		act.moveToElement(element).perform();
		driver.findElement(By.linkText("Alerts")).click();

		driver.findElement(By.className("analystic")).click();
		driver.findElement(By.xpath("//*[@id=\"OKTab\"]/button")).click();

		Alert alertWindow = null;
		// try {
		alertWindow = mywait.until(ExpectedConditions.alertIsPresent());
		alertWindow.accept();

	}

	@Test(priority = 4)
	public void checkConfirmBox() {

		driver.findElement(By.xpath("//*[@href=\"#CancelTab\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"CancelTab\"]/button")).click();

		Alert alertoc = mywait.until(ExpectedConditions.alertIsPresent());
		{

			alertoc.dismiss();

			String confirmBox = driver.findElement(By.id("demo")).getText();
			System.out.println(confirmBox);
		}
	}

	@Test(priority = 5)
	public void checkPromptBox() {

		driver.findElement(By.linkText("Alert with Textbox")).click();
		driver.findElement(By.xpath("//*[@id=\"Textbox\"]/button")).click();

		Alert alertTbox = mywait.until(ExpectedConditions.alertIsPresent());

		alertTbox.sendKeys(name);
		alertTbox.accept();

		String promptBox = driver.findElement(By.id("demo1")).getText();
		System.out.println(promptBox);
		String y = "Hello Om How are you today";

		assertEquals(y, promptBox, "Incorrect message displayed");
		System.out.println("Correct message displayed");

	}

	// @AfterTest
	@Test(priority = 6)
	public void afterTest() {
		System.out.println("Closing the browser");
		driver.quit();
	}

	public void readFromExcel() {
		try {
			File file = new File("C:\\Users/2320026/eclipse-workspace/MiniProject/data.xlsx");

			FileInputStream fis = new FileInputStream(file);

			XSSFWorkbook workbook = new XSSFWorkbook(fis);

			XSSFSheet sheet = workbook.getSheetAt(0);

			int totalRows = sheet.getLastRowNum();

			int totalCells = sheet.getRow(1).getLastCellNum();

			for (int r = 1; r <= totalRows; r++) {

				XSSFRow currentRow = sheet.getRow(r);

				for (int c = 0; c < totalCells; c++) {

					name = currentRow.getCell(c).toString();

					System.out.println(name);
				}
			}

			workbook.close();
			fis.close();

		}

		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}